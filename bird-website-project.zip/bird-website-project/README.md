# 🕊️ Bird World Website

Simple static website project themed about birds.

## 📂 Features
- Responsive layout
- Simple navigation
- Bird gallery section
- Contact form with JavaScript alert
- Clean folder structure

## 🚀 How to Run
Just open `index.html` in your browser.

## 📌 Perfect For
- Beginner HTML, CSS, JS project
- Portfolio project
- GitHub practice repository

---
Made with ❤️ for GitHub commit practice.
